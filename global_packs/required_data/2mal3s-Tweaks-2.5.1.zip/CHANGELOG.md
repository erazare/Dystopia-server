
### Added:
- warden tinnitus module
- auto harvest module
- first join message module

### Changed:
- license to LGPL-3.0

### Fixed:
- [Realistic Fire] bad description
- release include too many files
